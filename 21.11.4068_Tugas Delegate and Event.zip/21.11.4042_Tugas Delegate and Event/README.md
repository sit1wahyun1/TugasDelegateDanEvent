# TUGAS DELEGATE AND EVENT #
-> Tugas Pertemuan 8 Mata Kuliah Pemrograman Lanjut 
-> Nama  : Ari Valdy Pratama Arsyad
-> NIM   : 21.11.4042
-> Kelas : 21 IF 04