# TUGAS DELEGATE AND EVENT #
-> Tugas Pertemuan 8 Mata Kuliah Pemrograman Lanjut 
-> Nama  : Siti Wahyuni
-> NIM   : 21.11.4068
-> Kelas : 21 IF 04